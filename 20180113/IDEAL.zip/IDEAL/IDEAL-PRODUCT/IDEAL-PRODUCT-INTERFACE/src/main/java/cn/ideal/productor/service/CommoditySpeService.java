package cn.ideal.productor.service;

import cn.ideal.common.results.MessageResult;

public interface CommoditySpeService {

    MessageResult getSpeSpevBySpuId(Long id);
}
