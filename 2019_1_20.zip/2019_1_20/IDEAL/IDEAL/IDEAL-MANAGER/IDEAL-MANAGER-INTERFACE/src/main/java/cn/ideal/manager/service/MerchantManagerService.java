package cn.ideal.manager.service;

import cn.ideal.pojo.RelaMerchantProductor;

import java.util.List;

public interface MerchantManagerService {
   public List<RelaMerchantProductor> initMerchantApplyTable();
}
