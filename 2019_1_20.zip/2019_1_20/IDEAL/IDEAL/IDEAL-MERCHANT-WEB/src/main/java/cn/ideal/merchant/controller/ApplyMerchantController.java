package cn.ideal.merchant.controller;

import cn.ideal.common.pojo.MessageResult;
import cn.ideal.common.pojo.TableJsonResult;
import cn.ideal.common.pojo.TreeJsonResult;
import cn.ideal.merchant.service.ApplyMerchantService;
import cn.ideal.pojo.RelaMerPro;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.security.MessageDigest;
import java.util.List;

@Controller
public class ApplyMerchantController {
    @Autowired
    private ApplyMerchantService applyMerchantService;
    @RequestMapping("/merchant/initProductorTable/ApplyMerchant.do")
    @ResponseBody
    public TableJsonResult SearchCompanyForTable(Integer limit, Integer page, String search){
        return applyMerchantService.SearchCompanyForTable(limit,page,search);
    }
    @RequestMapping("/merchant/ApplyCompany/ApplyMerchant.do")
    @ResponseBody
    public MessageResult applyCompanyController(RelaMerPro relaMerPro){
        return applyMerchantService.ApplyCompany(relaMerPro);
    }
    @RequestMapping("/manager/initAlliedTable/ApplyMerchant.do")
    @ResponseBody
    public TableJsonResult initAppliedComTable(int limit,int page,Long merchantId){
        System.out.println("***************************"+merchantId);
        return applyMerchantService.initAppliedComTable(limit,page,merchantId);
    }
    @RequestMapping("/manager/findAllCommodity/ApplyMerchant.do")
    @ResponseBody
    public TableJsonResult getCommdityForMer(int limit,int page,String productorId){
        return applyMerchantService.getCommdityForMer(limit,page,productorId);
    }
    @RequestMapping("/manager/selectCommodityTable/ApplyMerchant.do")
    @ResponseBody
    public MessageResult ApplyCommodityForMer(String id,Long merchantId,Long productorId,String productorName,String merchantName){
        return applyMerchantService.ApplyCommodityForMer(id,merchantId,productorId,productorName,merchantName);
    }
}
