package cn.ideal.merchant.service;

import cn.ideal.common.pojo.MessageResult;
import cn.ideal.common.pojo.TableJsonResult;
import cn.ideal.pojo.RelaMerPro;

import java.util.List;

public interface ApplyMerchantService {
    public TableJsonResult SearchCompanyForTable(Integer limit, Integer page, String search);
    public MessageResult ApplyCompany(RelaMerPro relaMerPro);
    public TableJsonResult initAppliedComTable(int limit,int page,Long merchantId);
    public TableJsonResult getCommdityForMer(int limit,int page,String productorId);
    public MessageResult ApplyCommodityForMer(String id,Long merchantId,Long productorId,String productorName,String merchantName);
}
