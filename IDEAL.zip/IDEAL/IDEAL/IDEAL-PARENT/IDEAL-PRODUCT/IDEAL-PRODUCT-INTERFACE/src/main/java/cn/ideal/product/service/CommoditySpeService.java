package cn.ideal.product.service;

import cn.ideal.common.results.MessageResult;

public interface CommoditySpeService {

    MessageResult getSpeSpevBySpuId(Long id);
}
