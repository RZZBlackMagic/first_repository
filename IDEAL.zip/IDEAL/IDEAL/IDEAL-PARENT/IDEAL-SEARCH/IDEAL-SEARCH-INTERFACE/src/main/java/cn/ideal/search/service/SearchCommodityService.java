package cn.ideal.search.service;

import cn.ideal.common.results.MessageResult;
import cn.ideal.common.results.TableJsonResult;

/**
 * @author XINER
 * @create 2019-02-23 17:02
 * @desc
 **/
public interface SearchCommodityService {

    MessageResult importCommoditiesToIndex();

}
